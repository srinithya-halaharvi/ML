Welcome to GirlScript Manipal's Winter Mentorship Programme!</br>
This is the official Git Repository for the ML/AI Domain.</br>
Please go to the [Wiki](https://github.com/GirlScript-Manipal/ML-Winter-Bootcamp/wiki) page to view your weekly tasks. 
